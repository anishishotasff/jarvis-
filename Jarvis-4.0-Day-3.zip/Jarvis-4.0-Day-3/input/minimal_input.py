# jarvis/input/minimal_input.py
# Brief command processing
class MinimalInputProcessor:
    def __init__(self):
        pass

    def process_command(self, command):
        pass
