# jarvis/input/interrupt_handler.py
# Command interruption
class InterruptHandler:
    def __init__(self):
        pass

    def handle_interrupt(self):
        pass
