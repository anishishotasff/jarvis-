# jarvis/input/audio_detection.py
# Clap detection etc.
class AudioDetector:
    def __init__(self):
        pass

    def detect_clap(self):
        pass
