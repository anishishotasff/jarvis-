# jarvis/core/constants.py
# Global constants
class Constants:
    JARVIS_NAME = "Jarvis"
