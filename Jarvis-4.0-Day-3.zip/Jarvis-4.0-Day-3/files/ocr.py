# jarvis/files/ocr.py
# Text extraction from images
class OCR:
    def __init__(self):
        pass

    def extract_text_from_image(self, image_path):
        pass
