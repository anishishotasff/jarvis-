# jarvis/ai/llm_interface.py
# LLM connection
class LLMInterface:
    def __init__(self):
        pass

    def query_llm(self, prompt):
        pass
