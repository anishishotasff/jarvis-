# jarvis/ai/agents/search_agent.py
# Search agent
class SearchAgent:
    def __init__(self):
        pass

    def search_online(self, query):
        pass
