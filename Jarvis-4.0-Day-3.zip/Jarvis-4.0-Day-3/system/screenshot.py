# jarvis/system/screenshot.py
# Screen capture
class Screenshot:
    def __init__(self):
        pass

    def capture_screenshot(self):
        pass
