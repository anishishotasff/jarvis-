# jarvis/ui/system_tray.py
# System tray integration
class SystemTray:
    def __init__(self):
        pass

    def setup_tray_icon(self):
        pass
