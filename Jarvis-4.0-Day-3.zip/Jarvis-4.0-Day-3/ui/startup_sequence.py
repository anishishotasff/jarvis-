# jarvis/ui/startup_sequence.py
# Boot animation
class StartupSequence:
    def __init__(self):
        pass

    def run_animation(self):
        pass
