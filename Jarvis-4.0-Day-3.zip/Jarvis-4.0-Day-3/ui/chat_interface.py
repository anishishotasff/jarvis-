# jarvis/ui/chat_interface.py
# Chat UI component
import tkinter as tk

class ChatInterface(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
