# jarvis/ui/theme_manager.py
# UI themes
class ThemeManager:
    def __init__(self):
        pass

    def load_theme(self, theme_name):
        pass
