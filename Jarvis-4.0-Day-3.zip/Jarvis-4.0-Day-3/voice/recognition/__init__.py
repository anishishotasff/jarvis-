# Initialize the recognition package
from .active_provider import recognition_manager, listen

__all__ = ['recognition_manager', 'listen']