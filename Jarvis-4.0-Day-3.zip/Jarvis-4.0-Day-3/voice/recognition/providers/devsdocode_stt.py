from voice.recognition.providers.selenium_stt.provider import SeleniumSTTProvider

if __name__ == "__main__":
    from voice.recognition.providers.selenium_stt.main import *