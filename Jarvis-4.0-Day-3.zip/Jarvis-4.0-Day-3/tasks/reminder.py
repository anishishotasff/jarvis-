# jarvis/tasks/reminder.py
# Reminders
class Reminder:
    def __init__(self):
        pass

    def set_reminder(self, time, message):
        pass
